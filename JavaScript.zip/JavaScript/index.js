let X = 3;
let Y = 5;

const Numero1 = 50;
const Numero2 = 90;
const Numero3 = 35;
const Salario = 1800;

/*  Exercicios De Cálculos 1*/

// A
console.log(10+20*30);

// B
console.log(4**2/30);

// C
console.log((9**4+2)*6-1);

/*  Exercício da 2*/
console.log(10%3*10**1+1-10*4/2);

// Exercício da 3
console.log('Dev Claudir Santos');

// Exercicios da 4
console.log(2*X*3*Y);

// Exercicios da 5
console.log(Numero1+Numero2+Numero3);

// Exercicios da 6
console.log(Salario*2);
